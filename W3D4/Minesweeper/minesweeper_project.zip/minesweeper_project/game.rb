class Game
    def initialize(size = 10)
        @board = Board.new(size)
    end
end