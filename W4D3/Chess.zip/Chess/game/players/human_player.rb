require_relative "player"

class HumanPlayer

  def make_move(board)
  end
  
end