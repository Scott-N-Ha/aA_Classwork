

class Player

  def initialize(color, display)
    @color = color
    @display = display
  end

  
end