require_relative "piece"

class Pawn < Piece
  
  def symbol

  end

  def move_dirs

  end

  private
  def at_start_row?
  end

  def forward_dir
    1
  end

  def forward_steps
  end

  def side_attacks
  end
end