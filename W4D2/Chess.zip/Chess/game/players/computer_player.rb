require_relative "player"

class ComputerPlayer

  def make_move(board)
  end
  
end