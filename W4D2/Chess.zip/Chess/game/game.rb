require_relative "players/player.rb"
require_relative "board"
require_relative "display"

class Game

  def initialize
    @board
    @display
    @players = Hash.new
    @current_player
  end

  def play

  end

  private

  def notify_players

  end

  def swap_turn!
    
  end

end